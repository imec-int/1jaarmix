// Robby

var activeMenu = "intro";
var menus = ["intro","news","projects","results","slides","contact"]
var isScrollingToNext = false;
var newsIndex = 0;




/*
 Events
*/
$("#menu a").click(function(event){
	//event.preventDefault();

	/*$("#menu a").removeClass("menuItemActive");
	$("#menu a").addClass("menuItem");
	$(this).addClass("menuItemActive");*/
	highlightMenuItem("#"+$(this).attr("id"));
	activeMenu = $(this).attr("id");
	scrollToPage($(this).attr("href"));
	return false;
});

$("#next").click(function(event){

	if(!isScrollingToNext && (activeMenu != "callToAction" || menus.indexOf(activeMenu) == -1) ){
		//console.log(activeMenu+ " - " + menus.indexOf(activeMenu));
		activeMenu = activeMenu.replace("#","");
		activeMenu = menus[menus.indexOf(activeMenu)+1];
		highlightMenuItem("#a_"+activeMenu);
		scrollToPage("#"+activeMenu);
		isScrollingToNext = true;

		//console.log(activeMenu);
	}
	return false;
});

$("#news .indicator").click(function(event){
	newsIndex++;
	var maxIndex = $('#news #scroller .islide').length;
	if(newsIndex>=maxIndex)
		newsIndex=0;
	carouselScrollTo("news",newsIndex);
	console.log("translate");
	return false;
});
$("#slides .indicator").click(function(event){
	newsIndex++;
	var maxIndex = $('#slides #scroller .islide').length;
	if(newsIndex>=maxIndex)
		newsIndex=0;
	carouselScrollTo("slides",newsIndex);
	console.log("translate");
	return false;
});

var scroller=self.setInterval(function(){checkScroll()},400);

function checkScroll(){
	var scrollFromTop = $(this).scrollTop();
	// find the div which top is closest to top of browser
	var closest;
	var closestDistance = Infinity;
	$(".pageDiv").each(function(){
		//console.log($(this).attr("id") + " - " + Math.abs(scrollFromTop - $(this).offset().top) + " - " + closestDistance);

		if(Math.abs(scrollFromTop - $(this).offset().top) < closestDistance){
			var thisdiv = $(this).attr("id");
			closest = "#a_"+thisdiv;
			activeMenu = thisdiv;
			closestDistance = Math.abs(scrollFromTop - $(this).offset().top);
		}
	});
	if(closest){
		//console.log(closest+" is smallest");
		highlightMenuItem(closest);
		if(closest == "#a_callToAction"){
			$("#next").hide(100);
		}else{
			$("#next").show(100);
		}

	}
}


$(document).ready(function() {
	initNewsCarousel();
	initMixCarousel();
	resizeBigVideos();
	$(window).resize(function(){
		resizeBigVideos();
	});
});

function resizeBigVideos(){
	// video hoogtes aanpassen aan hoogte van window:
	$("#intromovie").height( $(window).height() - 200 );
}


function highlightMenuItem(active){
	/*console.log("highlight: ");
	console.log(active);*/
	$("#menu a").removeClass("menuItemActive");
	$("#menu a").addClass("menuItem");
	$(active).addClass("menuItemActive");
}

function initNewsCarousel () {
	var newsGestures = $("#news").hammer();

	// carousel indicators
	var maxIndex = $('#news #scroller .islide').length;
	if(maxIndex <= 1)
		$('#news .indicator').hide();
	$('#news .indicator').css("width",(16*maxIndex)+"px");


	//gesture events

	newsGestures.on("swipeleft", function(event){

		newsIndex++;
		var maxIndex = $('#news #scroller .islide').length;
		if(newsIndex>=maxIndex)
			newsIndex=0;
		carouselScrollTo("news",newsIndex);
		event.preventDefault();
	});

	newsGestures.on("swiperight", function(event){

		newsIndex--;
		var maxIndex = $('#news #scroller .islide').length;
		if(newsIndex<0)
			newsIndex=maxIndex-1;
		carouselScrollTo("news",newsIndex);
		event.preventDefault();
	});
}

function initMixCarousel () {
	var mixGestures = $("#slides").hammer();

	// carousel indicators
	var maxIndex = $('#slides #scroller .islide').length;
	if(maxIndex <= 1)
		$('#slides .indicator').hide();
	$('#slides .indicator').css("width",(16*maxIndex)+"px");


	//gesture events

	mixGestures.on("swipeleft", function(event){

		newsIndex++;
		var maxIndex = $('#slides #scroller .islide').length;
		if(newsIndex>=maxIndex)
			newsIndex=0;
		carouselScrollTo("slides",newsIndex);
		event.preventDefault();
	});

	mixGestures.on("swiperight", function(event){

		newsIndex--;
		var maxIndex = $('#slides #scroller .islide').length;
		if(newsIndex<0)
			newsIndex=maxIndex-1;
		carouselScrollTo("slides",newsIndex);
		event.preventDefault();
	});
}

// check scrolling
// highlight menu items




/*
 Makes DIVS full height
*/


/*
 PageChange
*/
/*function menuClick(e){
	var target = e.currentTarget.getAttribute("href");
	activeMenu = e.currentTarget.getAttribute("href");

}*/

/*
 Transition scroll to given page (div)
*/
function scrollToPage(pageId){
	var offset = $(pageId).offset().top;
	$('html, body').stop().animate({scrollTop: offset}, 400, function(){
		window.location = pageId;
		if( window.location.hash.match(/#results/) && Results!= null)
			window.location = pageId+Results.index;
		isScrollingToNext = false;
	});
	activeMenu = pageId;
}

/*
 Transition scroll to next horizontal item (div)
*/
function carouselScrollTo(pageId, index){
	var slideWidth = $('#'+pageId+' #scroller .islide:first').innerWidth();

	// console.log("slideWidth: " +slideWidth);
	// console.log("index: " +index);
	$('#'+pageId+' #scroller').stop().animate({transform:"translate3d(-"+(index*slideWidth)+"px,0,0)"}, 400);
	carouselIndicatorScrollTo(pageId, index);
}

/*
 Transition indicator to next horizontal item
*/
function carouselIndicatorScrollTo(pageId, index){
	$('#'+pageId+' .indicator .active').stop().animate({transform:"translate3d("+(index*16)+"px,0,0)"}, 400);
}
