exports.questiondata = [
	{
		question: 'Over 10 jaar kijkt men alleen nog maar on-demand of uitgesteld naar televisie.',
		category: 'Content',
		twitpic: 'http://twitpic.com/cstk8n'
	},
	{
		question: 'Als de media niet innoveert in Vlaanderen kijken we straks enkel naar buitenlandse content.',
		category: 'Content',
		twitpic: 'http://twitpic.com/cstkd3'
	},
	{
		question: 'Het mediabedrijf van de toekomst covert elk medium.',
		category: 'Content',
		twitpic: 'http://twitpic.com/cstl1p'
	},
	{
		question: 'Content aggregeren is een overbodige schakel in de waardeketen van media geworden.',
		category: 'Content',
		twitpic: 'http://twitpic.com/cstl6t'
	},
	{
		question: 'Journalistiek zal volautomatisch worden: content wordt gemaakt door algoritmes.',
		category: 'Content',
		twitpic: 'http://twitpic.com/cstl9n'
	},
	{
		question: 'Het doorspoelen of vermijden van reclame moet betalend worden.',
		category: 'Geld',
		twitpic: 'http://twitpic.com/cstlf6'
	},
	{
		question: 'Binnenkort zit alle kwaliteitscontent onherroepelijk achter een betaalmuur.',
		category: 'Geld',
		twitpic: 'http://twitpic.com/cstlmi'
	},
	{
		question: 'Vergelijkbare ROI cijfers over alle media heen zijn een must voor de mediasector.',
		category: 'Geld',
		twitpic: 'http://twitpic.com/cstlqd'
	},
	{
		question: 'Views en clicks zeggen niets over de impact van de reclame, sentimentanalyse is de nieuwe currency.',
		category: 'Geld',
		twitpic: 'http://twitpic.com/cstmj4'
	},
	{
		question: 'Targeted advertenties zijn de redding van het advertentiemodel.',
		category: 'Geld',
		twitpic: 'http://twitpic.com/cstmnw'
	},
	{
		question: 'Net zoals de iPad wordt Google Glass de norm binnen de drie jaar.',
		category: 'Innovatie',
		twitpic: 'http://twitpic.com/cstms7'
	},
	{
		question: 'De mediabedrijven moeten meer samenwerken om gecombineerde producten te maken.',
		category: 'Innovatie',
		twitpic: 'http://twitpic.com/cstmvn'
	},
	{
		question: 'Echte innovatie zit in de hardware, software zal altijd volgen.',
		category: 'Innovatie',
		twitpic: 'http://twitpic.com/cstne7'
	},
	{
		question: 'De strenge Europese privacy wetgeving is een competitief nadeel voor innovatie.',
		category: 'Innovatie',
		twitpic: 'http://twitpic.com/cstn77'
	},
	{
		question: 'De overheid moet reguleren hoe distributeurs en omroepen kunnen samenwerken.',
		category: 'Innovatie',
		twitpic: 'http://twitpic.com/cstnhs'
	}
];